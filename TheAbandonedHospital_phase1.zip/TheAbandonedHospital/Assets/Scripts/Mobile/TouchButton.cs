using UnityEngine;
using UnityEngine.EventSystems;

namespace Hospital.Mobile
{
    /// <summary>On-screen action button (Interact, Flashlight, Sprint, Crouch).</summary>
    public class TouchButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
    {
        public enum Action { Interact, Flashlight, Sprint, Crouch }
        public Action action;

        public void OnPointerDown(PointerEventData e)
        {
            switch (action)
            {
                case Action.Interact: MobileInput.InteractPressed = true; break;
                case Action.Flashlight: MobileInput.FlashlightPressed = true; break;
                case Action.Sprint: MobileInput.SprintHeld = true; break;
                case Action.Crouch: MobileInput.CrouchToggled = !MobileInput.CrouchToggled; break;
            }
        }

        public void OnPointerUp(PointerEventData e)
        {
            if (action == Action.Sprint) MobileInput.SprintHeld = false;
        }
    }
}
