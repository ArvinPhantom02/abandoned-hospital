using UnityEngine;
using UnityEngine.EventSystems;

namespace Hospital.Mobile
{
    /// <summary>Right-side transparent panel: dragging rotates the camera.</summary>
    public class TouchLookPad : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public float sensitivity = 0.15f;
        int pointerId = int.MinValue;

        public void OnPointerDown(PointerEventData e) { pointerId = e.pointerId; }

        public void OnDrag(PointerEventData e)
        {
            if (e.pointerId != pointerId) return;
            MobileInput.LookDelta += e.delta * sensitivity;
        }

        public void OnPointerUp(PointerEventData e)
        {
            if (e.pointerId == pointerId) pointerId = int.MinValue;
        }
    }
}
