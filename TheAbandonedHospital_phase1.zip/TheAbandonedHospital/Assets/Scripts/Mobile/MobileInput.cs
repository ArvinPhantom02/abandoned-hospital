using UnityEngine;

namespace Hospital.Mobile
{
    /// <summary>
    /// Static hub for touch input. UI widgets write to it, the player reads from it.
    /// Keyboard/mouse fallback is provided for testing in the Unity Editor.
    /// </summary>
    public static class MobileInput
    {
        public static Vector2 Move;
        public static Vector2 LookDelta;
        public static bool SprintHeld;
        public static bool CrouchToggled;
        public static bool InteractPressed;
        public static bool FlashlightPressed;

        public static void ConsumeFrameFlags()
        {
            InteractPressed = false;
            FlashlightPressed = false;
            LookDelta = Vector2.zero;
        }

        public static void Reset()
        {
            Move = Vector2.zero;
            LookDelta = Vector2.zero;
            SprintHeld = false;
            CrouchToggled = false;
            InteractPressed = false;
            FlashlightPressed = false;
        }
    }
}
