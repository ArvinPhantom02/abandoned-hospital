using UnityEngine;
using UnityEngine.EventSystems;

namespace Hospital.Mobile
{
    /// <summary>Left-side on-screen joystick. Attach to the joystick background (Image).</summary>
    public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public RectTransform handle;
        public float radius = 90f;

        RectTransform rect;
        int pointerId = int.MinValue;

        void Awake() { rect = (RectTransform)transform; }

        public void OnPointerDown(PointerEventData e)
        {
            pointerId = e.pointerId;
            OnDrag(e);
        }

        public void OnDrag(PointerEventData e)
        {
            if (e.pointerId != pointerId) return;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(rect, e.position, e.pressEventCamera, out var local);
            Vector2 v = Vector2.ClampMagnitude(local, radius);
            if (handle != null) handle.anchoredPosition = v;
            MobileInput.Move = v / radius;
        }

        public void OnPointerUp(PointerEventData e)
        {
            if (e.pointerId != pointerId) return;
            pointerId = int.MinValue;
            if (handle != null) handle.anchoredPosition = Vector2.zero;
            MobileInput.Move = Vector2.zero;
        }
    }
}
