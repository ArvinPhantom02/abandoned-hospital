using UnityEngine;
using Hospital.Core;
using Hospital.Mobile;

namespace Hospital.Player
{
    /// <summary>
    /// First-person controller: joystick move, touch look, sprint, crouch.
    /// Keyboard/mouse fallback (WASD, mouse, Shift, C, E, F) works in the Editor only.
    /// </summary>
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        [Header("References")]
        public Transform cameraPivot;

        [Header("Movement")]
        public float walkSpeed = 2.4f;
        public float sprintSpeed = 4.2f;
        public float crouchSpeed = 1.2f;
        public float gravity = -20f;

        [Header("Look")]
        public float maxPitch = 80f;

        [Header("Crouch")]
        public float standHeight = 1.8f;
        public float crouchHeight = 1.0f;
        public float eyeStand = 1.6f;
        public float eyeCrouch = 0.85f;

        [Header("Noise radii (metres)")]
        public float walkNoise = 6f;
        public float sprintNoise = 14f;
        public float crouchNoise = 2f;
        public float stepInterval = 0.5f;

        public bool IsSprinting { get; private set; }
        public bool IsCrouching { get; private set; }
        public bool Frozen { get; set; }

        CharacterController cc;
        float pitch;
        float verticalVelocity;
        float stepTimer;

        void Awake()
        {
            cc = GetComponent<CharacterController>();
            MobileInput.Reset();
        }

        void Update()
        {
            if (Frozen || (GameManager.Instance != null && GameManager.Instance.IsGameOver))
                return;

            Vector2 move = MobileInput.Move;
            Vector2 look = MobileInput.LookDelta;
            bool sprint = MobileInput.SprintHeld;

#if UNITY_EDITOR || UNITY_STANDALONE
            Vector2 kb = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
            if (kb.sqrMagnitude > 0.01f) move = kb;
            if (Input.GetMouseButton(1))
                look += new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y")) * 3f;
            if (Input.GetKey(KeyCode.LeftShift)) sprint = true;
            if (Input.GetKeyDown(KeyCode.C)) MobileInput.CrouchToggled = !MobileInput.CrouchToggled;
            if (Input.GetKeyDown(KeyCode.E)) MobileInput.InteractPressed = true;
            if (Input.GetKeyDown(KeyCode.F)) MobileInput.FlashlightPressed = true;
#endif

            // Look
            transform.Rotate(0f, look.x, 0f);
            pitch = Mathf.Clamp(pitch - look.y, -maxPitch, maxPitch);
            cameraPivot.localRotation = Quaternion.Euler(pitch, 0f, 0f);

            // Crouch
            IsCrouching = MobileInput.CrouchToggled;
            float targetH = IsCrouching ? crouchHeight : standHeight;
            cc.height = Mathf.Lerp(cc.height, targetH, 10f * Time.deltaTime);
            cc.center = new Vector3(0f, cc.height * 0.5f, 0f);
            float eye = IsCrouching ? eyeCrouch : eyeStand;
            Vector3 p = cameraPivot.localPosition;
            p.y = Mathf.Lerp(p.y, eye, 10f * Time.deltaTime);
            cameraPivot.localPosition = p;

            // Move
            IsSprinting = sprint && !IsCrouching && move.y > 0.1f;
            float speed = IsCrouching ? crouchSpeed : (IsSprinting ? sprintSpeed : walkSpeed);
            Vector3 dir = transform.right * move.x + transform.forward * move.y;
            if (dir.sqrMagnitude > 1f) dir.Normalize();

            if (cc.isGrounded && verticalVelocity < 0f) verticalVelocity = -2f;
            verticalVelocity += gravity * Time.deltaTime;

            Vector3 vel = dir * speed + Vector3.up * verticalVelocity;
            cc.Move(vel * Time.deltaTime);

            // Footstep noise
            if (move.sqrMagnitude > 0.05f && cc.isGrounded)
            {
                stepTimer -= Time.deltaTime * (IsSprinting ? 1.6f : 1f);
                if (stepTimer <= 0f)
                {
                    stepTimer = stepInterval;
                    float r = IsCrouching ? crouchNoise : (IsSprinting ? sprintNoise : walkNoise);
                    NoiseSystem.Emit(transform.position, r);
                }
            }

        }

        // Flags are cleared after every Update (including interactor/flashlight) has read them.
        void LateUpdate()
        {
            MobileInput.ConsumeFrameFlags();
        }
    }
}
