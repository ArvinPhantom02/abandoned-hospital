using System;
using UnityEngine;
using Hospital.Core;

namespace Hospital.Player
{
    public class PlayerHealth : MonoBehaviour
    {
        public float maxHealth = 100f;
        public float Current { get; private set; }
        public event Action<float> HealthChanged;

        void Awake() { Current = maxHealth; }

        public void Damage(float amount)
        {
            if (Current <= 0f) return;
            Current = Mathf.Max(0f, Current - amount);
            HealthChanged?.Invoke(Current / maxHealth);
            if (Current <= 0f && GameManager.Instance != null) GameManager.Instance.TriggerGameOver();
        }

        public void Heal(float amount)
        {
            Current = Mathf.Min(maxHealth, Current + amount);
            HealthChanged?.Invoke(Current / maxHealth);
        }
    }
}
