using UnityEngine;
using Hospital.Mobile;

namespace Hospital.Player
{
    /// <summary>Spot light on the camera with a draining battery.</summary>
    public class Flashlight : MonoBehaviour
    {
        public Light spot;
        public float maxBattery = 120f;      // seconds of light
        public float drainPerSecond = 1f;
        public float flickerBelow = 0.2f;    // fraction of battery
        public float maxIntensity = 3.5f;

        public float Battery { get; private set; }
        public float Fraction => Battery / maxBattery;
        public bool IsOn { get; private set; }

        void Awake()
        {
            Battery = maxBattery;
            if (spot != null) spot.enabled = false;
        }

        void Update()
        {
            if (MobileInput.FlashlightPressed) Toggle();
            if (!IsOn) return;

            Battery = Mathf.Max(0f, Battery - drainPerSecond * Time.deltaTime);
            if (Battery <= 0f) { SetOn(false); return; }

            float intensity = maxIntensity;
            if (Fraction < flickerBelow && Random.value < 0.15f) intensity *= Random.Range(0.1f, 0.6f);
            spot.intensity = intensity;
        }

        public void Toggle()
        {
            if (!IsOn && Battery <= 0f) return;
            SetOn(!IsOn);
        }

        void SetOn(bool on)
        {
            IsOn = on;
            if (spot != null) spot.enabled = on;
        }

        public void AddBattery(float seconds)
        {
            Battery = Mathf.Min(maxBattery, Battery + seconds);
        }
    }
}
