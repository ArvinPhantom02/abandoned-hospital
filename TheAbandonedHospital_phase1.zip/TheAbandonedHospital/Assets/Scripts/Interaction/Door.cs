using UnityEngine;
using Hospital.Core;

namespace Hospital.Interaction
{
    /// <summary>
    /// Hinged door. Put this on the root, with the door mesh as a child offset from the pivot
    /// so it swings around the hinge. Locked doors require requiredKeyId in the Inventory.
    /// </summary>
    public class Door : MonoBehaviour, IInteractable
    {
        public bool locked;
        public string requiredKeyId = "";
        public float openAngle = 95f;
        public float speed = 3f;
        [TextArea] public string objectiveOnOpen = "";

        public AudioClip openClip, closeClip, lockedClip;

        bool open;
        float current;
        AudioSource audioSrc;

        public string Prompt
        {
            get
            {
                if (locked) return "قفل است";
                return open ? "بستن در" : "باز کردن در";
            }
        }

        void Awake()
        {
            audioSrc = GetComponent<AudioSource>();
        }

        public void Interact(GameObject player)
        {
            if (locked)
            {
                var inv = player.GetComponent<Inventory>();
                if (inv != null && !string.IsNullOrEmpty(requiredKeyId) && inv.Has(requiredKeyId))
                {
                    locked = false;
                }
                else
                {
                    Play(lockedClip);
                    NoiseSystem.Emit(transform.position, 4f);
                    return;
                }
            }

            open = !open;
            Play(open ? openClip : closeClip);
            NoiseSystem.Emit(transform.position, 8f);

            if (open && GameManager.Instance != null)
            {
                if (!string.IsNullOrEmpty(objectiveOnOpen))
                    GameManager.Instance.SetObjective(objectiveOnOpen);
            }
        }

        void Update()
        {
            float target = open ? openAngle : 0f;
            current = Mathf.MoveTowards(current, target, Mathf.Abs(openAngle) * speed * Time.deltaTime);
            transform.localRotation = Quaternion.Euler(0f, current, 0f) * baseRotation;
        }

        Quaternion baseRotation = Quaternion.identity;
        void Start() { baseRotation = transform.localRotation; }

        void Play(AudioClip c)
        {
            if (c == null) return;
            if (audioSrc != null) audioSrc.PlayOneShot(c);
            else AudioSource.PlayClipAtPoint(c, transform.position);
        }
    }
}
