using UnityEngine;
using Hospital.Core;

namespace Hospital.Interaction
{
    public class KeyPickup : MonoBehaviour, IInteractable
    {
        public string keyId = "key_exit_corridor";
        public string displayName = "کلید زنگ‌زده";
        [TextArea] public string nextObjective = "درِ انتهای راهرو را باز کن";

        public string Prompt => "برداشتن " + displayName;

        public void Interact(GameObject player)
        {
            var inv = player.GetComponent<Inventory>();
            if (inv == null) return;
            inv.Add(keyId);
            NoiseSystem.Emit(transform.position, 3f);
            if (GameManager.Instance != null && !string.IsNullOrEmpty(nextObjective))
                GameManager.Instance.SetObjective(nextObjective);
            Destroy(gameObject);
        }

        void Update()
        {
            transform.Rotate(0f, 40f * Time.deltaTime, 0f, Space.World);
        }
    }
}
