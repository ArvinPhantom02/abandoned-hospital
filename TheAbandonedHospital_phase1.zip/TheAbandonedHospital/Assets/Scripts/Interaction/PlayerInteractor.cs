using System;
using UnityEngine;
using Hospital.Mobile;

namespace Hospital.Interaction
{
    /// <summary>Raycasts from the camera; Interact button triggers the focused IInteractable.</summary>
    public class PlayerInteractor : MonoBehaviour
    {
        public Camera cam;
        public float reach = 2.6f;
        public LayerMask mask = ~0;

        public IInteractable Focus { get; private set; }
        public event Action<string> PromptChanged;

        string lastPrompt = "";

        void Update()
        {
            IInteractable found = null;
            if (Physics.Raycast(cam.transform.position, cam.transform.forward, out var hit, reach, mask,
                    QueryTriggerInteraction.Ignore))
            {
                found = hit.collider.GetComponentInParent<IInteractable>();
            }

            Focus = found;
            string prompt = found != null ? found.Prompt : "";
            if (prompt != lastPrompt)
            {
                lastPrompt = prompt;
                PromptChanged?.Invoke(prompt);
            }

            if (MobileInput.InteractPressed && Focus != null)
                Focus.Interact(gameObject);
        }
    }
}
