using UnityEngine;

namespace Hospital.Interaction
{
    public interface IInteractable
    {
        /// <summary>Persian prompt shown on screen when the player looks at the object.</summary>
        string Prompt { get; }
        void Interact(GameObject player);
    }
}
