using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Hospital.Core;
using Hospital.Player;
using Hospital.Interaction;

namespace Hospital.UI
{
    /// <summary>Wires gameplay events to the on-screen HUD.</summary>
    public class HUD : MonoBehaviour
    {
        public TMP_Text objectiveText;
        public TMP_Text promptText;
        public TMP_Text inventoryText;
        public Image batteryFill;
        public Image healthFill;
        public GameObject gameOverPanel;
        public Button restartButton;

        public PlayerInteractor interactor;
        public Flashlight flashlight;
        public PlayerHealth health;
        public Inventory inventory;

        void Start()
        {
            if (gameOverPanel != null) gameOverPanel.SetActive(false);
            if (promptText != null) SetText(promptText, "");

            if (GameManager.Instance != null)
            {
                GameManager.Instance.ObjectiveChanged += OnObjective;
                GameManager.Instance.GameOver += OnGameOver;
                OnObjective(GameManager.Instance.CurrentObjective);
            }
            if (interactor != null) interactor.PromptChanged += p => SetText(promptText, p);
            if (health != null) health.HealthChanged += f => healthFill.fillAmount = f;
            if (inventory != null) inventory.ItemAdded += _ => RefreshInventory();
            if (restartButton != null)
                restartButton.onClick.AddListener(() => GameManager.Instance.Restart());

            if (healthFill != null) healthFill.fillAmount = 1f;
            RefreshInventory();
        }

        void Update()
        {
            if (flashlight != null && batteryFill != null)
                batteryFill.fillAmount = flashlight.Fraction;
        }

        void OnObjective(string text) { SetText(objectiveText, "هدف: " + text); }

        void OnGameOver()
        {
            if (gameOverPanel != null) gameOverPanel.SetActive(true);
        }

        void RefreshInventory()
        {
            if (inventoryText == null || inventory == null) return;
            var sb = new System.Text.StringBuilder("کوله‌پشتی: ");
            bool any = false;
            foreach (var id in inventory.All) { sb.Append(id).Append(' '); any = true; }
            if (!any) sb.Append("خالی");
            SetText(inventoryText, sb.ToString());
        }

        static void SetText(TMP_Text t, string s)
        {
            if (t == null) return;
            t.text = PersianText.Fix(s);
        }
    }
}
