using System.Collections.Generic;
using System.Text;

namespace Hospital.UI
{
    /// <summary>
    /// Minimal Persian/Arabic shaper + visual-order converter for TextMeshPro, which does not
    /// join Arabic-script letters by itself. Converts logical text to presentation forms
    /// (U+FB50-U+FEFF) and reverses it for left-to-right rendering.
    /// The font asset MUST contain Arabic Presentation Forms-A/B (e.g. Vazirmatn, Samim, Sahel).
    /// </summary>
    public static class PersianText
    {
        // base -> { isolated, final, initial, medial }; 0 = form does not exist (right-joining letters).
        static readonly Dictionary<char, char[]> Forms = new Dictionary<char, char[]>
        {
            {'ء', new[]{'ﺀ','\0','\0','\0'}},
            {'آ', new[]{'ﺁ','ﺂ','\0','\0'}},
            {'ا', new[]{'ﺍ','ﺎ','\0','\0'}},
            {'ئ', new[]{'ﺉ','ﺊ','ﺋ','ﺌ'}},
            {'ب', new[]{'ﺏ','ﺐ','ﺑ','ﺒ'}},
            {'پ', new[]{'ﭖ','ﭗ','ﭘ','ﭙ'}},
            {'ت', new[]{'ﺕ','ﺖ','ﺗ','ﺘ'}},
            {'ث', new[]{'ﺙ','ﺚ','ﺛ','ﺜ'}},
            {'ج', new[]{'ﺝ','ﺞ','ﺟ','ﺠ'}},
            {'چ', new[]{'ﭺ','ﭻ','ﭼ','ﭽ'}},
            {'ح', new[]{'ﺡ','ﺢ','ﺣ','ﺤ'}},
            {'خ', new[]{'ﺥ','ﺦ','ﺧ','ﺨ'}},
            {'د', new[]{'ﺩ','ﺪ','\0','\0'}},
            {'ذ', new[]{'ﺫ','ﺬ','\0','\0'}},
            {'ر', new[]{'ﺭ','ﺮ','\0','\0'}},
            {'ز', new[]{'ﺯ','ﺰ','\0','\0'}},
            {'ژ', new[]{'ﮊ','ﮋ','\0','\0'}},
            {'س', new[]{'ﺱ','ﺲ','ﺳ','ﺴ'}},
            {'ش', new[]{'ﺵ','ﺶ','ﺷ','ﺸ'}},
            {'ص', new[]{'ﺹ','ﺺ','ﺻ','ﺼ'}},
            {'ض', new[]{'ﺽ','ﺾ','ﺿ','ﻀ'}},
            {'ط', new[]{'ﻁ','ﻂ','ﻃ','ﻄ'}},
            {'ظ', new[]{'ﻅ','ﻆ','ﻇ','ﻈ'}},
            {'ع', new[]{'ﻉ','ﻊ','ﻋ','ﻌ'}},
            {'غ', new[]{'ﻍ','ﻎ','ﻏ','ﻐ'}},
            {'ف', new[]{'ﻑ','ﻒ','ﻓ','ﻔ'}},
            {'ق', new[]{'ﻕ','ﻖ','ﻗ','ﻘ'}},
            {'ک', new[]{'ﮎ','ﮏ','ﮐ','ﮑ'}},
            {'گ', new[]{'ﮒ','ﮓ','ﮔ','ﮕ'}},
            {'ل', new[]{'ﻝ','ﻞ','ﻟ','ﻠ'}},
            {'م', new[]{'ﻡ','ﻢ','ﻣ','ﻤ'}},
            {'ن', new[]{'ﻥ','ﻦ','ﻧ','ﻨ'}},
            {'و', new[]{'ﻭ','ﻮ','\0','\0'}},
            {'ه', new[]{'ﻩ','ﻪ','ﻫ','ﻬ'}},
            {'ی', new[]{'ﯼ','ﯽ','ﯾ','ﯿ'}},
            {'ة', new[]{'ﺓ','ﺔ','\0','\0'}},
        };

        static char Normalize(char c)
        {
            if (c == 'ي') return 'ی'; // Arabic yeh -> Persian yeh
            if (c == 'ك') return 'ک'; // Arabic kaf -> Persian kaf
            return c;
        }

        static bool IsArabicLetter(char c) => Forms.ContainsKey(c);
        // Can connect to the NEXT letter (has an initial/medial form).
        static bool JoinsNext(char c) => Forms.TryGetValue(c, out var f) && f[2] != '\0';
        static bool IsHarakat(char c) => c >= 'ً' && c <= 'ٟ';

        public static string Fix(string logical)
        {
            if (string.IsNullOrEmpty(logical)) return logical;
            var lines = logical.Split('\n');
            for (int i = 0; i < lines.Length; i++) lines[i] = FixLine(lines[i]);
            return string.Join("\n", lines);
        }

        static string FixLine(string s)
        {
            // 1. Shape
            var shaped = new List<char>(s.Length);
            int n = s.Length;
            for (int i = 0; i < n; i++)
            {
                char c = Normalize(s[i]);
                if (!IsArabicLetter(c))
                {
                    if (c == '‌') { shaped.Add('‌'); continue; } // ZWNJ kept as a breaker, removed below
                    shaped.Add(c);
                    continue;
                }

                // lam + alef ligature
                if (c == 'ل' && i + 1 < n)
                {
                    char nx = Normalize(s[i + 1]);
                    char lig = '\0';
                    bool prevJoin = PrevJoins(s, i);
                    if (nx == 'ا') lig = prevJoin ? 'ﻼ' : 'ﻻ';
                    else if (nx == 'آ') lig = prevJoin ? 'ﻶ' : 'ﻵ';
                    if (lig != '\0') { shaped.Add(lig); i++; continue; }
                }

                bool prev = PrevJoins(s, i);
                bool next = NextExists(s, i);
                var f = Forms[c];
                char outc;
                bool canNext = f[2] != '\0';
                if (prev && next && canNext) outc = f[3];
                else if (prev) outc = f[1] != '\0' ? f[1] : f[0];
                else if (next && canNext) outc = f[2];
                else outc = f[0];
                shaped.Add(outc);
            }

            // 2. Visual reorder: reverse the line, but keep runs of LTR chars (Latin, digits) in order.
            var result = new StringBuilder(shaped.Count);
            int k = shaped.Count - 1;
            while (k >= 0)
            {
                char c = shaped[k];
                if (c == '‌') { k--; continue; }
                if (IsLtr(c))
                {
                    int end = k;
                    while (k >= 0 && IsLtr(shaped[k])) k--;
                    for (int j = k + 1; j <= end; j++) result.Append(shaped[j]);
                }
                else
                {
                    result.Append(Mirror(c));
                    k--;
                }
            }
            return result.ToString();
        }

        static bool PrevJoins(string s, int i)
        {
            for (int p = i - 1; p >= 0; p--)
            {
                char c = Normalize(s[p]);
                if (IsHarakat(c)) continue;
                return JoinsNext(c);
            }
            return false;
        }

        static bool NextExists(string s, int i)
        {
            for (int p = i + 1; p < s.Length; p++)
            {
                char c = Normalize(s[p]);
                if (IsHarakat(c)) continue;
                return IsArabicLetter(c);
            }
            return false;
        }

        static bool IsLtr(char c)
        {
            return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '_';
        }

        static char Mirror(char c)
        {
            switch (c)
            {
                case '(': return ')';
                case ')': return '(';
                case '[': return ']';
                case ']': return '[';
                case '«': return '»';
                case '»': return '«';
                default: return c;
            }
        }
    }
}
