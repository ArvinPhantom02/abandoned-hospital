#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;
using TMPro;
using Unity.AI.Navigation;
using Hospital.Core;
using Hospital.Player;
using Hospital.Mobile;
using Hospital.Interaction;
using Hospital.Enemy;
using Hospital.UI;

namespace Hospital.EditorTools
{
    /// <summary>
    /// Menu: Hospital > Build First Section Scene
    /// Builds the whole playable corridor scene from primitives, bakes the NavMesh,
    /// creates the HUD and saves Assets/Scenes/Hospital_Section1.unity.
    /// </summary>
    public static class HospitalSceneBuilder
    {
        const float CorridorLength = 30f;
        const float CorridorWidth = 3.2f;
        const float Height = 3f;

        [MenuItem("Hospital/Build First Section Scene")]
        public static void Build()
        {
            if (TMP_Settings.instance == null || TMP_Settings.defaultFontAsset == null)
            {
                EditorUtility.DisplayDialog("TextMeshPro",
                    "Import TMP Essentials first:\nWindow > TextMeshPro > Import TMP Essential Resources\nThen run this menu again.", "OK");
                return;
            }

            ProjectSetup.Apply();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            SetupLighting();
            var floorRoot = BuildCorridor();
            var player = BuildPlayer();
            var enemy = BuildEnemy(player.transform);
            BuildProps(player.transform);
            BuildUI(player);

            // GameManager + ambience
            var gm = new GameObject("GameManager");
            gm.AddComponent<GameManager>();
            var amb = new GameObject("Ambience");
            amb.AddComponent<AudioSource>();
            amb.AddComponent<AmbienceController>();

            // EventSystem
            var es = new GameObject("EventSystem");
            es.AddComponent<UnityEngine.EventSystems.EventSystem>();
            es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();

            // Bake navmesh
            var surface = floorRoot.AddComponent<NavMeshSurface>();
            surface.collectObjects = CollectObjects.All;
            surface.useGeometry = NavMeshCollectGeometry.PhysicsColliders;
            surface.BuildNavMesh();

            Directory.CreateDirectory("Assets/Scenes");
            const string path = "Assets/Scenes/Hospital_Section1.unity";
            EditorSceneManager.SaveScene(scene, path);

            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(path, true) };
            Debug.Log("Hospital section built and saved: " + path + ". Press Play.");
        }

        // ---------------- Lighting ----------------

        static void SetupLighting()
        {
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.03f, 0.035f, 0.045f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogColor = new Color(0.02f, 0.025f, 0.03f);
            RenderSettings.fogDensity = 0.045f;
        }

        // ---------------- Geometry ----------------

        static Material Mat(string name, Color c, float smooth = 0.2f)
        {
            Directory.CreateDirectory("Assets/Materials");
            string p = "Assets/Materials/" + name + ".mat";
            var m = AssetDatabase.LoadAssetAtPath<Material>(p);
            if (m != null) return m;
            var shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Standard");
            m = new Material(shader) { color = c };
            if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smooth);
            AssetDatabase.CreateAsset(m, p);
            return m;
        }

        static GameObject Box(string name, Transform parent, Vector3 pos, Vector3 scale, Material m)
        {
            var g = GameObject.CreatePrimitive(PrimitiveType.Cube);
            g.name = name;
            g.transform.SetParent(parent, false);
            g.transform.position = pos;
            g.transform.localScale = scale;
            g.GetComponent<Renderer>().sharedMaterial = m;
            GameObjectUtility.SetStaticEditorFlags(g,
                StaticEditorFlags.BatchingStatic | StaticEditorFlags.NavigationStatic | StaticEditorFlags.OccluderStatic |
                StaticEditorFlags.OccludeeStatic | StaticEditorFlags.ContributeGI);
            return g;
        }

        static GameObject BuildCorridor()
        {
            var root = new GameObject("Level");
            var floorM = Mat("M_Floor", new Color(0.18f, 0.2f, 0.19f), 0.45f);
            var wallM = Mat("M_Wall", new Color(0.32f, 0.35f, 0.33f), 0.1f);
            var ceilM = Mat("M_Ceiling", new Color(0.22f, 0.23f, 0.22f), 0.05f);
            var trimM = Mat("M_Trim", new Color(0.1f, 0.1f, 0.1f), 0.2f);

            float L = CorridorLength, W = CorridorWidth, H = Height;
            float zc = L * 0.5f;

            Box("Floor", root.transform, new Vector3(0, -0.1f, zc), new Vector3(W, 0.2f, L), floorM);
            Box("Ceiling", root.transform, new Vector3(0, H + 0.1f, zc), new Vector3(W, 0.2f, L), ceilM);
            Box("WallLeft", root.transform, new Vector3(-W * 0.5f - 0.1f, H * 0.5f, zc), new Vector3(0.2f, H, L), wallM);
            Box("WallRight", root.transform, new Vector3(W * 0.5f + 0.1f, H * 0.5f, zc), new Vector3(0.2f, H, L), wallM);
            Box("WallStart", root.transform, new Vector3(0, H * 0.5f, -0.1f), new Vector3(W, H, 0.2f), wallM);

            // Side-room dividers every 7.5 m to create alcoves / hiding spots
            for (int i = 1; i <= 3; i++)
            {
                float z = i * 7.5f;
                Box("Pillar" + i + "L", root.transform, new Vector3(-W * 0.5f + 0.25f, H * 0.5f, z), new Vector3(0.5f, H, 0.5f), trimM);
                Box("Pillar" + i + "R", root.transform, new Vector3(W * 0.5f - 0.25f, H * 0.5f, z), new Vector3(0.5f, H, 0.5f), trimM);
            }

            // Cover: gurneys / cabinets along the walls
            var propM = Mat("M_Prop", new Color(0.35f, 0.38f, 0.4f), 0.3f);
            Box("Cabinet1", root.transform, new Vector3(-1.2f, 0.5f, 6f), new Vector3(0.7f, 1f, 1.4f), propM);
            Box("Gurney", root.transform, new Vector3(1.1f, 0.45f, 12.5f), new Vector3(0.8f, 0.9f, 2f), propM);
            Box("Cabinet2", root.transform, new Vector3(-1.2f, 0.5f, 19f), new Vector3(0.7f, 1f, 1.4f), propM);

            // Dim corridor lights (every 7.5m, low-intensity, no shadows for performance)
            for (int i = 0; i < 4; i++)
            {
                var lg = new GameObject("CorridorLight" + i);
                lg.transform.SetParent(root.transform);
                lg.transform.position = new Vector3(0, H - 0.3f, 3.5f + i * 7.5f);
                var l = lg.AddComponent<Light>();
                l.type = LightType.Point;
                l.range = 6f;
                l.intensity = (i == 2) ? 0.15f : 0.45f;
                l.color = new Color(0.75f, 0.85f, 0.7f);
                l.shadows = LightShadows.None;
                if (i == 1) lg.AddComponent<FlickerLight>();
            }

            // Dead-end behind the locked door
            Box("ExitRoomFloor", root.transform, new Vector3(0, -0.1f, L + 3f), new Vector3(W, 0.2f, 6f), floorM);
            Box("ExitRoomCeiling", root.transform, new Vector3(0, H + 0.1f, L + 3f), new Vector3(W, 0.2f, 6f), ceilM);
            Box("ExitRoomWallL", root.transform, new Vector3(-W * 0.5f - 0.1f, H * 0.5f, L + 3f), new Vector3(0.2f, H, 6f), wallM);
            Box("ExitRoomWallR", root.transform, new Vector3(W * 0.5f + 0.1f, H * 0.5f, L + 3f), new Vector3(0.2f, H, 6f), wallM);
            Box("ExitRoomEnd", root.transform, new Vector3(0, H * 0.5f, L + 6.1f), new Vector3(W, H, 0.2f), wallM);

            // End wall with the door gap: two side blocks + lintel
            float gap = 1.1f;
            float sideW = (W - gap) * 0.5f;
            Box("EndWallL", root.transform, new Vector3(-(gap * 0.5f + sideW * 0.5f), H * 0.5f, L), new Vector3(sideW, H, 0.2f), wallM);
            Box("EndWallR", root.transform, new Vector3((gap * 0.5f + sideW * 0.5f), H * 0.5f, L), new Vector3(sideW, H, 0.2f), wallM);
            Box("EndLintel", root.transform, new Vector3(0, 2.6f, L), new Vector3(gap, 0.8f, 0.2f), wallM);

            return root;
        }

        // ---------------- Player ----------------

        static GameObject BuildPlayer()
        {
            var p = new GameObject("Player");
            p.tag = "Player";
            p.transform.position = new Vector3(0, 0.05f, 1.2f);

            var cc = p.AddComponent<CharacterController>();
            cc.height = 1.8f; cc.radius = 0.3f; cc.center = new Vector3(0, 0.9f, 0);
            cc.stepOffset = 0.3f;

            var pivot = new GameObject("CameraPivot");
            pivot.transform.SetParent(p.transform, false);
            pivot.transform.localPosition = new Vector3(0, 1.6f, 0);

            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            camGo.transform.SetParent(pivot.transform, false);
            var cam = camGo.AddComponent<Camera>();
            cam.nearClipPlane = 0.05f;
            cam.farClipPlane = 60f;
            cam.fieldOfView = 70f;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = Color.black;
            camGo.AddComponent<AudioListener>();

            // Flashlight spot
            var fl = new GameObject("FlashlightSpot");
            fl.transform.SetParent(camGo.transform, false);
            fl.transform.localPosition = new Vector3(0.12f, -0.1f, 0.1f);
            var spot = fl.AddComponent<Light>();
            spot.type = LightType.Spot;
            spot.range = 16f;
            spot.spotAngle = 60f;
            spot.innerSpotAngle = 25f;
            spot.intensity = 3.5f;
            spot.color = new Color(1f, 0.95f, 0.8f);
            spot.shadows = LightShadows.Soft;

            var pc = p.AddComponent<PlayerController>();
            pc.cameraPivot = pivot.transform;
            var flash = p.AddComponent<Flashlight>();
            flash.spot = spot;
            p.AddComponent<PlayerHealth>();
            p.AddComponent<Inventory>();
            var inter = p.AddComponent<PlayerInteractor>();
            inter.cam = cam;

            var src = p.AddComponent<AudioSource>();
            src.playOnAwake = false;
            var fs = p.AddComponent<FootstepAudio>();
            fs.isPlayer = true;

            return p;
        }

        // ---------------- Enemy ----------------

        static GameObject BuildEnemy(Transform player)
        {
            var e = new GameObject("Enemy_Doctor");
            e.transform.position = new Vector3(0, 0.05f, 22f);

            // Placeholder body: capsule. Replace with a rigged humanoid and assign its Animator.
            var body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            body.name = "Body";
            body.transform.SetParent(e.transform, false);
            body.transform.localPosition = new Vector3(0, 1f, 0);
            body.transform.localScale = new Vector3(0.6f, 0.9f, 0.6f);
            Object.DestroyImmediate(body.GetComponent<Collider>());
            body.GetComponent<Renderer>().sharedMaterial = Mat("M_Enemy", new Color(0.55f, 0.1f, 0.1f), 0.1f);

            var eyes = new GameObject("Eyes");
            eyes.transform.SetParent(e.transform, false);
            eyes.transform.localPosition = new Vector3(0, 1.65f, 0.2f);

            var agent = e.AddComponent<NavMeshAgent>();
            agent.radius = 0.35f; agent.height = 1.9f; agent.acceleration = 10f; agent.angularSpeed = 240f;
            agent.stoppingDistance = 0.4f;

            var col = e.AddComponent<CapsuleCollider>();
            col.height = 1.9f; col.radius = 0.35f; col.center = new Vector3(0, 0.95f, 0);
            var rb = e.AddComponent<Rigidbody>();
            rb.isKinematic = true;

            // Patrol points
            var pts = new Transform[4];
            float[] zs = { 24f, 14f, 6f, 16f };
            float[] xs = { 0.6f, -0.6f, 0.4f, -0.4f };
            var ptsRoot = new GameObject("PatrolPoints");
            for (int i = 0; i < 4; i++)
            {
                var pt = new GameObject("P" + i);
                pt.transform.SetParent(ptsRoot.transform);
                pt.transform.position = new Vector3(xs[i], 0.05f, zs[i]);
                pts[i] = pt.transform;
            }

            var ai = e.AddComponent<EnemyAI>();
            ai.player = player;
            ai.eyes = eyes.transform;
            ai.patrolPoints = pts;
            ai.sightBlockers = ~0;

            e.AddComponent<AudioSource>().playOnAwake = false;
            var fs = e.AddComponent<FootstepAudio>();
            fs.volume = 0.9f;
            return e;
        }

        // ---------------- Props: key and door ----------------

        static void BuildProps(Transform player)
        {
            // Key on the cabinet near the start
            var key = GameObject.CreatePrimitive(PrimitiveType.Cube);
            key.name = "Key";
            key.transform.position = new Vector3(-1.2f, 1.1f, 6f);
            key.transform.localScale = new Vector3(0.08f, 0.02f, 0.25f);
            key.GetComponent<Renderer>().sharedMaterial = Mat("M_Key", new Color(0.9f, 0.7f, 0.15f), 0.8f);
            var kp = key.AddComponent<KeyPickup>();
            kp.keyId = "key_exit_corridor";
            // Collider is bigger so a phone player can aim at it easily
            var bc = key.GetComponent<BoxCollider>();
            bc.size = new Vector3(4f, 10f, 2f);
            var glow = new GameObject("KeyGlow");
            glow.transform.SetParent(key.transform, false);
            var gl = glow.AddComponent<Light>();
            gl.type = LightType.Point; gl.range = 2.5f; gl.intensity = 0.8f;
            gl.color = new Color(1f, 0.85f, 0.3f); gl.shadows = LightShadows.None;

            // Door at the end of the corridor (hinge at left edge of the gap)
            float gap = 1.1f;
            var hinge = new GameObject("ExitDoor");
            hinge.transform.position = new Vector3(-gap * 0.5f, 0f, CorridorLength);
            var panel = GameObject.CreatePrimitive(PrimitiveType.Cube);
            panel.name = "Panel";
            panel.transform.SetParent(hinge.transform, false);
            panel.transform.localPosition = new Vector3(gap * 0.5f, 1.1f, 0f);
            panel.transform.localScale = new Vector3(gap, 2.2f, 0.08f);
            panel.GetComponent<Renderer>().sharedMaterial = Mat("M_Door", new Color(0.25f, 0.17f, 0.1f), 0.2f);
            var aud = hinge.AddComponent<AudioSource>();
            aud.spatialBlend = 1f; aud.playOnAwake = false;
            var door = hinge.AddComponent<Door>();
            door.locked = true;
            door.openAngle = -95f; // swings away from the player
            door.requiredKeyId = "key_exit_corridor";
            door.objectiveOnOpen = "از درِ باز عبور کن و راهی برای خروج پیدا کن";
            door.openClip = ProceduralAudio.DoorCreak();   // runtime-generated; replace with real clips later
            door.closeClip = door.openClip;
            door.lockedClip = ProceduralAudio.LockedRattle();
        }

        // ---------------- UI ----------------

        static void BuildUI(GameObject player)
        {
            var canvasGo = new GameObject("HUD");
            var canvas = canvasGo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGo.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 0.5f;
            canvasGo.AddComponent<GraphicRaycaster>();

            var hud = canvasGo.AddComponent<HUD>();
            hud.interactor = player.GetComponent<PlayerInteractor>();
            hud.flashlight = player.GetComponent<Flashlight>();
            hud.health = player.GetComponent<PlayerHealth>();
            hud.inventory = player.GetComponent<Inventory>();

            // Look pad: right half of the screen (behind the buttons)
            var look = Panel("LookPad", canvasGo.transform, new Vector2(0.45f, 0f), new Vector2(1f, 1f), Vector2.zero, Vector2.zero, new Color(0, 0, 0, 0));
            look.gameObject.AddComponent<TouchLookPad>();

            // Joystick (bottom-left)
            var joy = Anchored("Joystick", canvasGo.transform, new Vector2(0, 0), new Vector2(260, 260), new Vector2(60, 60), new Color(1, 1, 1, 0.12f));
            var handle = Anchored("Handle", joy.transform, new Vector2(0.5f, 0.5f), new Vector2(110, 110), Vector2.zero, new Color(1, 1, 1, 0.35f), true);
            var vj = joy.gameObject.AddComponent<VirtualJoystick>();
            vj.handle = handle; vj.radius = 100f;

            // Buttons (bottom-right)
            Button(canvasGo.transform, "BtnInteract", "تعامل", TouchButton.Action.Interact, new Vector2(-70, 80), 150);
            Button(canvasGo.transform, "BtnFlash", "چراغ‌قوه", TouchButton.Action.Flashlight, new Vector2(-250, 80), 130);
            Button(canvasGo.transform, "BtnSprint", "دویدن", TouchButton.Action.Sprint, new Vector2(-70, 270), 120);
            Button(canvasGo.transform, "BtnCrouch", "خم شدن", TouchButton.Action.Crouch, new Vector2(-230, 270), 120);

            // Texts
            hud.objectiveText = Text("Objective", canvasGo.transform, new Vector2(0.5f, 1f), new Vector2(0, -40), new Vector2(1100, 70), 36, TextAlignmentOptions.Center);
            hud.promptText = Text("Prompt", canvasGo.transform, new Vector2(0.5f, 0.5f), new Vector2(0, -90), new Vector2(700, 60), 40, TextAlignmentOptions.Center);
            hud.inventoryText = Text("Inventory", canvasGo.transform, new Vector2(1f, 1f), new Vector2(-30, -110), new Vector2(600, 50), 28, TextAlignmentOptions.Right);

            // Crosshair dot
            Anchored("Crosshair", canvasGo.transform, new Vector2(0.5f, 0.5f), new Vector2(6, 6), Vector2.zero, new Color(1, 1, 1, 0.6f), true);

            // Bars (top-left)
            hud.batteryFill = Bar("Battery", canvasGo.transform, new Vector2(30, -30), new Color(1f, 0.85f, 0.3f));
            hud.healthFill = Bar("Health", canvasGo.transform, new Vector2(30, -62), new Color(0.8f, 0.1f, 0.1f));

            // Game over
            var go = Panel("GameOver", canvasGo.transform, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, new Color(0, 0, 0, 0.85f));
            var t = Text("GameOverText", go.transform, new Vector2(0.5f, 0.5f), new Vector2(0, 60), new Vector2(900, 120), 72, TextAlignmentOptions.Center);
            t.text = PersianText.Fix("تو مُردی");
            t.color = new Color(0.8f, 0.1f, 0.1f);
            var rb = Button(go.transform, "BtnRestart", "شروع دوباره", TouchButton.Action.Interact, new Vector2(0, -80), 200, false);
            hud.restartButton = rb.gameObject.AddComponent<UnityEngine.UI.Button>();
            hud.gameOverPanel = go.gameObject;
        }

        static RectTransform Panel(string name, Transform parent, Vector2 aMin, Vector2 aMax, Vector2 oMin, Vector2 oMax, Color c)
        {
            var g = new GameObject(name, typeof(RectTransform), typeof(Image));
            g.transform.SetParent(parent, false);
            var r = (RectTransform)g.transform;
            r.anchorMin = aMin; r.anchorMax = aMax; r.offsetMin = oMin; r.offsetMax = oMax;
            g.GetComponent<Image>().color = c;
            return r;
        }

        static RectTransform Anchored(string name, Transform parent, Vector2 anchor, Vector2 size, Vector2 pos, Color c, bool centered = false)
        {
            var g = new GameObject(name, typeof(RectTransform), typeof(Image));
            g.transform.SetParent(parent, false);
            var r = (RectTransform)g.transform;
            r.anchorMin = r.anchorMax = anchor;
            r.pivot = centered ? new Vector2(0.5f, 0.5f) : anchor;
            r.sizeDelta = size;
            r.anchoredPosition = pos;
            g.GetComponent<Image>().color = c;
            return r;
        }

        static RectTransform Button(Transform parent, string name, string label, TouchButton.Action action, Vector2 pos, float size, bool addTouch = true)
        {
            var anchor = parent.name == "GameOver" ? new Vector2(0.5f, 0.5f) : new Vector2(1, 0);
            var r = Anchored(name, parent, anchor, new Vector2(size, size), pos, new Color(1, 1, 1, 0.18f), parent.name == "GameOver");
            if (parent.name == "GameOver") r.sizeDelta = new Vector2(size * 1.8f, size * 0.6f);
            if (addTouch) { var tb = r.gameObject.AddComponent<TouchButton>(); tb.action = action; }
            var t = Text(name + "_Label", r, new Vector2(0.5f, 0.5f), Vector2.zero, r.sizeDelta, 28, TextAlignmentOptions.Center);
            t.text = PersianText.Fix(label);
            return r;
        }

        static TMP_Text Text(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size, float fontSize, TextAlignmentOptions align)
        {
            var g = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
            g.transform.SetParent(parent, false);
            var r = (RectTransform)g.transform;
            r.anchorMin = r.anchorMax = anchor;
            r.pivot = anchor == new Vector2(1f, 1f) ? new Vector2(1f, 1f) : new Vector2(0.5f, anchor.y == 1f ? 1f : 0.5f);
            r.sizeDelta = size; r.anchoredPosition = pos;
            var t = g.GetComponent<TextMeshProUGUI>();
            var persian = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>("Assets/Fonts/Persian SDF.asset");
            if (persian != null) t.font = persian;
            t.fontSize = fontSize; t.alignment = align; t.color = new Color(0.9f, 0.9f, 0.85f);
            t.raycastTarget = false;
            return t;
        }

        static Image Bar(string name, Transform parent, Vector2 pos, Color fill)
        {
            var bg = Anchored(name + "Bg", parent, new Vector2(0, 1), new Vector2(300, 22), new Vector2(pos.x, pos.y), new Color(0, 0, 0, 0.5f));
            var f = Anchored(name + "Fill", bg, new Vector2(0, 0.5f), new Vector2(300, 22), Vector2.zero, fill);
            f.pivot = new Vector2(0, 0.5f);
            var img = f.GetComponent<Image>();
            img.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
            img.type = Image.Type.Filled;
            img.fillMethod = Image.FillMethod.Horizontal;
            img.fillOrigin = 0;
            img.fillAmount = 1f;
            img.raycastTarget = false;
            return img;
        }
    }
}
#endif
