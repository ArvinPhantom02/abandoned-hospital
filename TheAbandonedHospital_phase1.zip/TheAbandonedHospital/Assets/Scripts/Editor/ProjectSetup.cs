#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Hospital.EditorTools
{
    /// <summary>
    /// Menu: Hospital > Setup Project (URP + Android)
    /// Creates a URP asset tuned for mobile, assigns it, and applies Android player settings.
    /// </summary>
    public static class ProjectSetup
    {
        [MenuItem("Hospital/Setup Project (URP + Android)")]
        public static void Apply()
        {
            Directory.CreateDirectory("Assets/Settings");

            // --- URP asset ---
            const string urpPath = "Assets/Settings/URP_Mobile.asset";
            var urp = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(urpPath);
            if (urp == null)
            {
                urp = UniversalRenderPipelineAsset.Create();
                AssetDatabase.CreateAsset(urp, urpPath);
            }
            urp.renderScale = 1f;
            urp.supportsHDR = false;                // cheaper on mobile
            urp.msaaSampleCount = 2;
            urp.shadowDistance = 18f;
            urp.supportsCameraDepthTexture = false;
            urp.supportsCameraOpaqueTexture = false;
            EditorUtility.SetDirty(urp);

            GraphicsSettings.defaultRenderPipeline = urp;
            for (int i = 0; i < QualitySettings.names.Length; i++)
            {
                QualitySettings.SetQualityLevel(i, false);
                QualitySettings.renderPipeline = urp;
            }

            // --- Android player settings ---
            PlayerSettings.companyName = "HospitalGame";
            PlayerSettings.productName = "THE ABANDONED HOSPITAL";
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.hospitalgame.abandoned");
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.Vulkan, GraphicsDeviceType.OpenGLES3 });
            PlayerSettings.colorSpace = ColorSpace.Linear;

            AssetDatabase.SaveAssets();
            Debug.Log("Project setup applied (URP asset + Android settings).");
        }
    }
}
#endif
