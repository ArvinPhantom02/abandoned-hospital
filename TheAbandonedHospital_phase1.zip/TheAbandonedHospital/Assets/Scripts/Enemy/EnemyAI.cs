using UnityEngine;
using UnityEngine.AI;
using Hospital.Core;
using Hospital.Player;

namespace Hospital.Enemy
{
    public enum EnemyState { Idle, Patrol, Investigate, Chase, Search }

    /// <summary>
    /// Human enemy. It does NOT know where the player is: it only reacts to
    /// (a) sight - range, view cone and an unobstructed raycast, shortened if the player crouches
    ///     in the dark, and
    /// (b) hearing - noises emitted through NoiseSystem within their radius.
    /// After losing the player it walks to the last known position and then searches around it.
    /// </summary>
    [RequireComponent(typeof(NavMeshAgent))]
    public class EnemyAI : MonoBehaviour
    {
        [Header("References")]
        public Transform player;
        public Transform eyes;
        public Transform[] patrolPoints;
        public Animator animator;               // optional; expects float "Speed"

        [Header("Speeds")]
        public float patrolSpeed = 1.4f;
        public float chaseSpeed = 3.6f;

        [Header("Sight")]
        public float viewDistance = 14f;
        public float viewAngle = 100f;
        public float crouchViewMultiplier = 0.6f;
        public LayerMask sightBlockers = ~0;

        [Header("Behaviour")]
        public float idleAtPointTime = 3f;
        public float loseSightTime = 2.5f;
        public float searchDuration = 9f;
        public float attackRange = 1.4f;
        public float attackDamage = 34f;
        public float attackCooldown = 1.2f;

        public EnemyState State { get; private set; } = EnemyState.Patrol;

        NavMeshAgent agent;
        PlayerController playerCtrl;
        PlayerHealth playerHealth;
        int patrolIndex;
        float stateTimer;
        float sinceSeen;
        float attackTimer;
        Vector3 lastKnown;
        float searchRepathTimer;

        static readonly int SpeedHash = Animator.StringToHash("Speed");

        void Awake()
        {
            agent = GetComponent<NavMeshAgent>();
            if (eyes == null) eyes = transform;
        }

        void Start()
        {
            if (player != null)
            {
                playerCtrl = player.GetComponent<PlayerController>();
                playerHealth = player.GetComponent<PlayerHealth>();
            }
            GoPatrol();
        }

        void OnEnable() { NoiseSystem.NoiseEmitted += OnNoise; }
        void OnDisable() { NoiseSystem.NoiseEmitted -= OnNoise; }

        void Update()
        {
            if (player == null) return;
            if (GameManager.Instance != null && GameManager.Instance.IsGameOver)
            {
                agent.isStopped = true;
                UpdateAnim();
                return;
            }

            bool sees = CanSeePlayer();
            if (sees)
            {
                sinceSeen = 0f;
                lastKnown = player.position;
                if (State != EnemyState.Chase) EnterChase();
            }
            else sinceSeen += Time.deltaTime;

            attackTimer -= Time.deltaTime;

            switch (State)
            {
                case EnemyState.Idle: TickIdle(); break;
                case EnemyState.Patrol: TickPatrol(); break;
                case EnemyState.Investigate: TickInvestigate(); break;
                case EnemyState.Chase: TickChase(sees); break;
                case EnemyState.Search: TickSearch(); break;
            }

            UpdateAnim();
        }

        // ---------- Perception ----------

        bool CanSeePlayer()
        {
            Vector3 target = player.position + Vector3.up * 1.2f;
            Vector3 to = target - eyes.position;
            float dist = to.magnitude;

            float range = viewDistance;
            if (playerCtrl != null && playerCtrl.IsCrouching) range *= crouchViewMultiplier;
            if (dist > range) return false;

            // Very close: always noticed if not blocked, even outside the cone.
            bool close = dist < 2.0f;
            if (!close && Vector3.Angle(eyes.forward, to) > viewAngle * 0.5f) return false;

            if (Physics.Raycast(eyes.position, to.normalized, out var hit, dist, sightBlockers,
                    QueryTriggerInteraction.Ignore))
            {
                return hit.transform == player || hit.transform.IsChildOf(player);
            }
            return true;
        }

        void OnNoise(Vector3 pos, float radius)
        {
            if (State == EnemyState.Chase) return;
            // Distance along the NavMesh would be better; straight-line is a cheap approximation.
            if ((pos - transform.position).sqrMagnitude > radius * radius) return;

            lastKnown = pos;
            EnterInvestigate(pos);
        }

        // ---------- State entry ----------

        void GoPatrol()
        {
            State = EnemyState.Patrol;
            agent.isStopped = false;
            agent.speed = patrolSpeed;
            if (patrolPoints != null && patrolPoints.Length > 0)
                agent.SetDestination(patrolPoints[patrolIndex].position);
        }

        void EnterIdle()
        {
            State = EnemyState.Idle;
            stateTimer = idleAtPointTime;
            agent.isStopped = true;
        }

        void EnterInvestigate(Vector3 pos)
        {
            State = EnemyState.Investigate;
            agent.isStopped = false;
            agent.speed = patrolSpeed * 1.3f;
            agent.SetDestination(pos);
        }

        void EnterChase()
        {
            State = EnemyState.Chase;
            agent.isStopped = false;
            agent.speed = chaseSpeed;
        }

        void EnterSearch()
        {
            State = EnemyState.Search;
            stateTimer = searchDuration;
            searchRepathTimer = 0f;
            agent.isStopped = false;
            agent.speed = patrolSpeed * 1.2f;
        }

        // ---------- State ticks ----------

        void TickIdle()
        {
            stateTimer -= Time.deltaTime;
            if (stateTimer <= 0f)
            {
                if (patrolPoints != null && patrolPoints.Length > 0)
                    patrolIndex = (patrolIndex + 1) % patrolPoints.Length;
                GoPatrol();
            }
        }

        void TickPatrol()
        {
            if (patrolPoints == null || patrolPoints.Length == 0) { EnterIdle(); return; }
            if (!agent.pathPending && agent.remainingDistance <= agent.stoppingDistance + 0.3f)
                EnterIdle();
        }

        void TickInvestigate()
        {
            if (!agent.pathPending && agent.remainingDistance <= agent.stoppingDistance + 0.5f)
                EnterSearch();
        }

        void TickChase(bool sees)
        {
            // Heads toward where it last saw/heard the player; it never reads the player's live position
            // unless it currently sees them.
            agent.SetDestination(lastKnown);

            float d = Vector3.Distance(transform.position, player.position);
            if (sees && d <= attackRange && attackTimer <= 0f && playerHealth != null)
            {
                attackTimer = attackCooldown;
                playerHealth.Damage(attackDamage);
                NoiseSystem.Emit(player.position, 10f);
            }

            if (!sees && sinceSeen > loseSightTime &&
                !agent.pathPending && agent.remainingDistance <= agent.stoppingDistance + 0.6f)
                EnterSearch();
        }

        void TickSearch()
        {
            stateTimer -= Time.deltaTime;
            searchRepathTimer -= Time.deltaTime;

            if (searchRepathTimer <= 0f)
            {
                searchRepathTimer = 2.5f;
                Vector3 random = lastKnown + Random.insideUnitSphere * 6f;
                if (NavMesh.SamplePosition(random, out var nav, 4f, NavMesh.AllAreas))
                    agent.SetDestination(nav.position);
            }

            if (stateTimer <= 0f) GoPatrol();
        }

        void UpdateAnim()
        {
            if (animator != null)
                animator.SetFloat(SpeedHash, agent.velocity.magnitude, 0.1f, Time.deltaTime);
        }

        void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, viewDistance);
        }
    }
}
