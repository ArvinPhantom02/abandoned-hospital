using UnityEngine;
using UnityEngine.AI;
using Hospital.Player;

namespace Hospital.Core
{
    /// <summary>
    /// 3D footsteps. Works for the player (CharacterController) and the enemy (NavMeshAgent).
    /// Assign custom clips or leave empty to use generated placeholders.
    /// </summary>
    [RequireComponent(typeof(AudioSource))]
    public class FootstepAudio : MonoBehaviour
    {
        public AudioClip[] clips;
        public float walkInterval = 0.55f;
        public float runInterval = 0.32f;
        public float runSpeedThreshold = 3f;
        public float volume = 0.7f;
        public bool isPlayer;

        AudioSource src;
        CharacterController cc;
        NavMeshAgent agent;
        PlayerController pc;
        float timer;
        Vector3 lastPos;

        void Awake()
        {
            src = GetComponent<AudioSource>();
            src.spatialBlend = isPlayer ? 0.2f : 1f;
            src.minDistance = 1.5f;
            src.maxDistance = 22f;
            src.rolloffMode = AudioRolloffMode.Linear;
            cc = GetComponent<CharacterController>();
            agent = GetComponent<NavMeshAgent>();
            pc = GetComponent<PlayerController>();
            if (clips == null || clips.Length == 0)
                clips = new[] { ProceduralAudio.Footstep(1f), ProceduralAudio.Footstep(1.3f), ProceduralAudio.Footstep(0.8f) };
            lastPos = transform.position;
        }

        void Update()
        {
            float speed = 0f;
            if (agent != null && agent.enabled) speed = agent.velocity.magnitude;
            else if (cc != null) speed = ((transform.position - lastPos) / Mathf.Max(Time.deltaTime, 0.0001f)).magnitude;
            lastPos = transform.position;

            if (speed < 0.3f) { timer = 0.1f; return; }
            if (pc != null && pc.IsCrouching) { timer -= Time.deltaTime * 0.6f; }
            else timer -= Time.deltaTime;

            if (timer <= 0f)
            {
                timer = speed > runSpeedThreshold ? runInterval : walkInterval;
                src.pitch = Random.Range(0.9f, 1.1f);
                float v = volume * ((pc != null && pc.IsCrouching) ? 0.35f : 1f);
                src.PlayOneShot(clips[Random.Range(0, clips.Length)], v);
            }
        }
    }
}
