using UnityEngine;

namespace Hospital.Core
{
    /// <summary>Randomly flickering ceiling light.</summary>
    [RequireComponent(typeof(Light))]
    public class FlickerLight : MonoBehaviour
    {
        public float minFactor = 0.1f;
        public float flickerChance = 0.08f;

        Light l;
        float baseIntensity;
        float holdTimer;

        void Awake()
        {
            l = GetComponent<Light>();
            baseIntensity = l.intensity;
        }

        void Update()
        {
            holdTimer -= Time.deltaTime;
            if (holdTimer > 0f) return;
            holdTimer = Random.Range(0.03f, 0.12f);
            l.intensity = Random.value < flickerChance ? baseIntensity * Random.Range(minFactor, 0.5f) : baseIntensity;
        }
    }
}
