using System;
using System.Collections.Generic;
using UnityEngine;

namespace Hospital.Core
{
    /// <summary>Simple key/item inventory identified by string ids.</summary>
    public class Inventory : MonoBehaviour
    {
        readonly HashSet<string> items = new HashSet<string>();
        public event Action<string> ItemAdded;

        public bool Has(string id) => items.Contains(id);

        public void Add(string id)
        {
            if (items.Add(id)) ItemAdded?.Invoke(id);
        }

        public IEnumerable<string> All => items;
    }
}
