using System;
using UnityEngine;

namespace Hospital.Core
{
    /// <summary>
    /// Central game state: objectives, game over, simple events.
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        public event Action<string> ObjectiveChanged;
        public event Action GameOver;

        public string CurrentObjective { get; private set; } = "";
        public bool IsGameOver { get; private set; }

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
        }

        void Start()
        {
            Application.targetFrameRate = 60;
            QualitySettings.vSyncCount = 0;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            SetObjective("پیدا کردن کلید درِ انتهای راهرو");
        }

        public void SetObjective(string text)
        {
            CurrentObjective = text;
            ObjectiveChanged?.Invoke(text);
        }

        public void TriggerGameOver()
        {
            if (IsGameOver) return;
            IsGameOver = true;
            GameOver?.Invoke();
        }

        public void Restart()
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(
                UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
        }
    }
}
