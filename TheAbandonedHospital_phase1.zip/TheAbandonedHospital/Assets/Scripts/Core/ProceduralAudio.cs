using UnityEngine;

namespace Hospital.Core
{
    /// <summary>
    /// Generates simple placeholder sounds at runtime so the prototype has audio with zero imported assets.
    /// Replace by real clips (Assets/Audio/...) by assigning them on the components that use them.
    /// </summary>
    public static class ProceduralAudio
    {
        const int Rate = 22050;

        public static AudioClip Footstep(float pitch = 1f)
        {
            int len = (int)(Rate * 0.16f);
            var data = new float[len];
            var rng = new System.Random(7);
            float lp = 0f;
            for (int i = 0; i < len; i++)
            {
                float t = i / (float)len;
                float env = Mathf.Exp(-t * 14f);
                float noise = (float)(rng.NextDouble() * 2 - 1);
                lp += (noise - lp) * (0.18f * pitch);
                data[i] = lp * env * 0.9f;
            }
            return Make("footstep", data);
        }

        public static AudioClip DoorCreak()
        {
            int len = (int)(Rate * 0.9f);
            var data = new float[len];
            float phase = 0f;
            for (int i = 0; i < len; i++)
            {
                float t = i / (float)len;
                float f = 140f + 90f * Mathf.Sin(t * 9f) + 60f * t;
                phase += f / Rate;
                float env = Mathf.Sin(t * Mathf.PI);
                data[i] = (Mathf.Sign(Mathf.Sin(phase * 2f * Mathf.PI)) * 0.25f) * env * 0.5f;
            }
            return Make("door_creak", data);
        }

        public static AudioClip LockedRattle()
        {
            int len = (int)(Rate * 0.25f);
            var data = new float[len];
            var rng = new System.Random(3);
            for (int i = 0; i < len; i++)
            {
                float t = i / (float)len;
                float env = Mathf.Exp(-t * 9f) * (Mathf.Sin(t * 60f) > 0 ? 1f : 0.3f);
                data[i] = (float)(rng.NextDouble() * 2 - 1) * env * 0.5f;
            }
            return Make("locked", data);
        }

        public static AudioClip AmbienceDrone()
        {
            int len = Rate * 8;
            var data = new float[len];
            for (int i = 0; i < len; i++)
            {
                float t = i / (float)Rate;
                // loop-safe: all frequencies have integer cycles over 8 s
                float s = Mathf.Sin(2f * Mathf.PI * 48f * t) * 0.35f
                        + Mathf.Sin(2f * Mathf.PI * 72.5f * t) * 0.2f
                        + Mathf.Sin(2f * Mathf.PI * 0.25f * t) * 0.1f * Mathf.Sin(2f * Mathf.PI * 110f * t);
                data[i] = s * 0.5f;
            }
            return Make("ambience", data);
        }

        static AudioClip Make(string name, float[] data)
        {
            var clip = AudioClip.Create(name, data.Length, 1, Rate, false);
            clip.SetData(data, 0);
            return clip;
        }
    }
}
