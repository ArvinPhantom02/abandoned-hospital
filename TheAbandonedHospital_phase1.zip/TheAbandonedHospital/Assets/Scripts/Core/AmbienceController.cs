using UnityEngine;

namespace Hospital.Core
{
    /// <summary>Looping hospital ambience. Uses a generated drone if no clip is assigned.</summary>
    [RequireComponent(typeof(AudioSource))]
    public class AmbienceController : MonoBehaviour
    {
        public AudioClip clip;
        [Range(0f, 1f)] public float volume = 0.35f;

        void Start()
        {
            var src = GetComponent<AudioSource>();
            src.clip = clip != null ? clip : ProceduralAudio.AmbienceDrone();
            src.loop = true;
            src.spatialBlend = 0f;
            src.volume = volume;
            src.Play();
        }
    }
}
