using System;
using UnityEngine;

namespace Hospital.Core
{
    /// <summary>Static noise bus. Player/doors emit noise, enemies listen.</summary>
    public static class NoiseSystem
    {
        public static event Action<Vector3, float> NoiseEmitted;

        /// <param name="radius">Distance in metres within which the noise can be heard.</param>
        public static void Emit(Vector3 position, float radius)
        {
            NoiseEmitted?.Invoke(position, radius);
        }
    }
}
