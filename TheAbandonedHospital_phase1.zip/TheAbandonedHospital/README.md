# THE ABANDONED: HOSPITAL — Phase 1–2 prototype (first playable section)

Status: **source project only. Not compiled, not run, no APK built.** I had no Unity Editor in my
environment, so none of this has been tested. Expect to fix a few compile errors on first open.

## What is in this build
- First-person player: joystick, touch look, sprint (hold), crouch (toggle), interact, flashlight with battery, health
- Noise system: footsteps, doors and pickups emit noise that the enemy can hear
- Human enemy: patrol, idle, investigate (heard noise), chase, search around last known position;
  sight uses range + view cone + line-of-sight raycast; crouching shortens sight range
- 30 m corridor with a key on a cabinet and a locked door at the end (opens with the key)
- One objective chain: find the key -> open the door
- Persian HUD (shaped + reordered by `PersianText`), runtime-generated placeholder sounds (no audio assets needed)
- Editor tools that build the scene and apply URP/Android settings

Not done yet (later phases): hospital rooms, puzzles, documents, story/endings, save/load, main menu,
graphics presets, FPS options, dynamic resolution, LOD/occlusion, real audio, enemy animations.

## How to run
1. Install **Unity 2022.3 LTS** with the Android Build Support module (incl. OpenJDK + SDK/NDK).
2. Unity Hub -> Add -> select the `TheAbandonedHospital` folder (let it resolve packages; URP 14, AI Navigation, TMP).
3. `Window > TextMeshPro > Import TMP Essential Resources`.
4. Persian font: download a free font with Arabic Presentation Forms (e.g. Vazirmatn), then
   `Window > TextMeshPro > Font Asset Creator` (Atlas 2048, Unicode range `0020-007E,0600-06FF,FB50-FDFF,FE70-FEFF`,
   Dynamic or Static) and save it as `Assets/Fonts/Persian SDF.asset`. Without it Persian text shows as boxes.
5. Menu **Hospital > Build First Section Scene**. This applies URP + Android settings, builds the level, bakes the
   NavMesh, saves `Assets/Scenes/Hospital_Section1.unity`.
6. Press Play. Editor keyboard fallback: WASD move, right-mouse drag to look, Shift sprint, C crouch, E interact, F flashlight.

## Build the APK (when you are ready)
`File > Build Settings > Android > Switch Platform > Build` (scene is already in the list).
Test on a real phone before trusting any performance number.

## Important files
- `Assets/Scripts/Player/PlayerController.cs`, `Flashlight.cs`, `PlayerHealth.cs`
- `Assets/Scripts/Mobile/*` (joystick, look pad, buttons)
- `Assets/Scripts/Enemy/EnemyAI.cs`
- `Assets/Scripts/Interaction/*` (Door, KeyPickup, PlayerInteractor)
- `Assets/Scripts/Editor/HospitalSceneBuilder.cs`, `ProjectSetup.cs`

## Known limits
- The enemy is a red capsule until you import a rigged humanoid: assign its Animator on `EnemyAI`
  (it sets a float parameter named `Speed`; use it as a blend-tree driver for idle/walk/run).
- Level is built from primitives; replace with real hospital models/materials as assets are imported.
